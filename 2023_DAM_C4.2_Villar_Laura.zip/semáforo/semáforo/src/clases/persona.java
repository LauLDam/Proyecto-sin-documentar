package clases;

/**
 * Clase persona, es extendida por estudiante y profesor
 * 
 * @author Laura
 * @version 1.0
 * 
 */
public class persona {
	/**
	 * La edad de la persona
	 */
	int i_Edad;
	/**
	 * El nombre de la persona
	 */
	String s_Nombre;
}
